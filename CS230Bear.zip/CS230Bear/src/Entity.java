import java.awt.Graphics2D;

public class Entity {
	
	int x, y;
	
	public Entity(int x, int y) {
		this.x = x;
		this.y = y;
		
	}
	
	public void update() {
		
	}
	
	public void draw(Graphics2D g2d) {

}
}
