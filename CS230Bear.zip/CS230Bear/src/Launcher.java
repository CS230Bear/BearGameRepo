

public class Launcher 
{
	public static void main (String[] args)
	
	{
	Game game = new Game("BearGame!", 1920, 1080);
	game.start();
	
	}

}
