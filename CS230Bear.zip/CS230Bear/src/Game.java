import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;




public class Game  implements Runnable
{

	private DisplayScreen display;
	public int width, height;
	public String title;
	private boolean running = false;
	private Thread thread;
	
	public BufferStrategy bs;
	public Graphics g;
	
	public BufferedImage testImage;
	public BufferedImage testImage1;
	public BufferedImage testSheet;
	public BufferedImage BearMvmt;
	public SpriteSheet sheet;
	
	public Game(String title, int width, int height)
	{
		this.width = width;
		this.height = height;
		this.title = title;
		
	}
	
	
	
	private void init()
	{
		display = new DisplayScreen(title, width, height);
		testImage = ImageLoader.loadImage("/textures/BearV1.png");
		testImage1 = ImageLoader.loadImage("/textures/Ganjo.jpg");
		testSheet = ImageLoader.loadImage("/textures/Sheet.png");
		BearMvmt = ImageLoader.loadImage("/textures/bear.png");
		sheet = new SpriteSheet(testSheet);
	}
	
	private void tick()
	{
		
	}
	// here things show up on screen
	private void render()
	{
		bs = display.getCanvas().getBufferStrategy();
		if(bs == null)
		{
			display.getCanvas().createBufferStrategy(3);
			return;
		}
		g = bs.getDrawGraphics();
		// before you draw new clear screen
		g.clearRect(0,0, width, height);
		
		
	
		rectangle();
		images();
		
		//end draw and make them show
		bs.show();
		g.dispose();
		
	}
	public void images()
	{
		g.drawImage(BearMvmt,25,600, null);
		g.drawImage(sheet.crop(0, 0,64, 64), 100, 400, null);
		g.drawImage(sheet.crop(64, 0,64, 64), 0, 400, null);
	}
	
	public void rectangle()
	{
		g = bs.getDrawGraphics();
		// Here you create shapes and color them etc
				g.setColor(Color.magenta);
				g.fillRect(0,0, width, height);
			// Creates non-interactable platforms "platform"
				
				g.setColor(Color.BLACK);
				g.fillRect(0, 700, width, 420);
				
				g.setColor(Color.GREEN);
				g.fillRect(100, 400, 100, 15);
				
				g.setColor(Color.GREEN);
				g.fillRect(300, 200, 100, 15);
				
				g.setColor(Color.GREEN);
				g.fillRect(430, 250, 100, 15);
				
				g.setColor(Color.red);
				g.fillRect(10,50, 50, 70);
				g.setColor(Color.GREEN);
				g.fillRect(0, 0, 10, 10);
	}
	
	
	
	public void run()
	{
		init();
		while(running)
		{
			tick();
			render();	
		}
		
		stop();
	}
	
	public synchronized void start ()
	
	{	if (running)
			return;
		running = true;
		thread = new Thread(this);
		thread.start();
	}
	
	public synchronized void stop ()
	{	if(!running)
		return;
		 running =false;
		 
		 
		try 
	{
		thread.join();
		} catch (InterruptedException e) {
		
		e.printStackTrace();
		}
		
	}
	
}



