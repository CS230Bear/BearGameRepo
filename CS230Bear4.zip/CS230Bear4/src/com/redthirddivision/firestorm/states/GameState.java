
package com.redthirddivision.firestorm.states;

import java.awt.Graphics2D;

import com.redthirddivision.firestorm.Game;
import com.redthirddivision.firestorm.world.TileMap;


public class GameState implements State {


    private TileMap tileMap;
    
    public void init() {
        tileMap = new TileMap("level1");
    }

    public void enter() {}

    public void tick(StateManager stateManager) {
        tileMap.tick();
    }

    public void render(Graphics2D g) {
        tileMap.render(g, Game.WIDTH, Game.HEIGHT);
    }

    public void exit() {
    }

    public String getName() {
        return "level1";
    }

}
