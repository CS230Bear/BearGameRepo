
package com.redthirddivision.firestorm.entities;


import java.awt.event.KeyEvent;

import com.redthirddivision.firestorm.input.KeyInput;
import com.redthirddivision.firestorm.rendering.textures.Animation;
import com.redthirddivision.firestorm.rendering.textures.Texture;
import com.redthirddivision.firestorm.world.TileMap;


public class Player extends Mob {

    public Player(double x, double y, TileMap tileMap) {
        super(new Texture(new Texture("spritesheet_templateAdded"), 1, 1, 64), x, y, tileMap,
                new Animation(5,
                        new Texture(new Texture("spritesheet_templateAdded"), 1, 1, 64),
                        new Texture(new Texture("spritesheet_templateAdded"), 2, 1, 64)));
                        /*new Texture(new Texture("player_sheet"), 3, 1, 64),
                        new Texture(new Texture("player_sheet"), 4, 1, 64),
                        new Texture(new Texture("player_sheet"), 1, 2, 64),
                        new Texture(new Texture("player_sheet"), 2, 2, 64)));*/

    }

    @Override
    public void tick() {
        if(KeyInput.isDown(KeyEvent.VK_SPACE)) jump(20);
//        if(KeyInput.isDown(KeyEvent.VK_S)) dy = 2;a
        if(KeyInput.isDown(KeyEvent.VK_A)) dx = -2;
        if(KeyInput.isDown(KeyEvent.VK_D)) dx = 2;
        
//        if(KeyInput.wasReleased(KeyEvent.VK_W) || KeyInput.wasReleased(KeyEvent.VK_S)) dy = 0;
        if(KeyInput.wasReleased(KeyEvent.VK_A) || KeyInput.wasReleased(KeyEvent.VK_D)) dx = 0;
        super.tick();
    }

}
